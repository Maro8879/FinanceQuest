# Finance Quest
Mobilna aplikacja (Unity, uGUI, C#) do nauki finansów osobistych w stylu Duolingo.
Kursy → rozdziały → levele. Treść w JSON (Content/), importer zamienia ją na assety.

## Treść i edytor (praca we dwóch przez GitHub)

- Treść: `Assets/FinanceQuest/Content/<kurs>/course.json` + jeden plik na rozdział (`<rozdział>.json`).
- Edytor: otwórz `Tools/ContentEditor.html` w Chrome lub Edge → „Otwórz folder Content” → wskaż `Assets/FinanceQuest/Content`.
- Zapis: przycisk „Zapisz zmiany” lub Ctrl+S. Potem w GitHub Desktop: Commit + Push. Kolega robi Pull.
- Gdy plik zmieni się na dysku (np. po Pull), edytor pokaże żółty pasek: „Wczytaj nową wersję” albo „Porównaj”.
- Najlepiej, żeby każdy pracował na innym rozdziale – wtedy nie ma konfliktów.
- Unity samo składa treść do `Resources/Content/ContentDatabase.asset` po każdej zmianie JSON-a
  (ręcznie: menu Finance Quest → Import Content). Ostrzeżenia o brakach widać w Console.
